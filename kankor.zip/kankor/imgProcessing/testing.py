def test():
    print("Haseeb")